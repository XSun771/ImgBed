package com.example.springfox.web;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class OrderController {

    @PostMapping("/place")
    public String place(@RequestBody Order order){
        return order.toString();
    }

    @RequestMapping("/hello")
    public String hello(){
        return "hello";
    }

    class Order {
        int id;
        String description;
        int cunstomer_id;

        @Override
        public String toString() {
            return "Order{" +
                    "id=" + id +
                    ", description='" + description + '\'' +
                    ", cunstomer_id=" + cunstomer_id +
                    '}';
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getCunstomer_id() {
            return cunstomer_id;
        }

        public void setCunstomer_id(int cunstomer_id) {
            this.cunstomer_id = cunstomer_id;
        }
    }
}
